<?php

class PHPParser_Node_Expr_Cast_Unset extends PHPParser_Node_Expr_Cast
{
}
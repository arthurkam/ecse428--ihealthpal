CHANGELOG
=========

* 1.0.2 (2014-xx-xx)

  * Validate missing arguments (@bajbnet).

* 1.0.1 (2013-10-25)

  * Lower PHP requirement to 5.3.

* 1.0.0 (2013-08-02)

  * Initial release.

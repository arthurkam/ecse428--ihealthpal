<?php
class ConcreteWithMyCustomExtensionTest extends AbstractTest
{
    public function testTwo()
    {
    }
}

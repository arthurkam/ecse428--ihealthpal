<?php
// short desc
abstract class A {
    /* abst meth: */
    public static  abstract function method();
}
